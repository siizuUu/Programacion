package identificadores.asociacion;
public class asociacion {
    public static void main(String[] args) {
        
        // Asociacion de tipos de datos adecuados.

        int numeroDeTelefono
        short $totalVentas = totalVentas
        String mi_nombre => miNombre
        String 4everYoung 
        int _variable
        short #precioProducto
        String usuario-email
        int $saldoCuenta
        String primeraClase
        int mi_123_variable
        String _nombreUsuario
        int 12345_valor
        String &variable
        short $precioUnitario
        short #contador_de_inventario
        byte miVariable%descuento
        short producto1
        byte 3añosDeExperiencia
        int _mi_numero_de_cuenta
        int mi_salario$$
        String $nombreCliente
        int variable#temporal
        int _variable99
        String mi_@direccion
        int precio-total
        byte 5HorasTrabajo
        byte !descuento
        short codigoDeProducto
        short _MiIdentificador
        short valor#unitario
        
    }

}
