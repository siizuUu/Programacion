package identificadores.constantes;

public class constantes {
    public static void main(String[] args) {
        final byte alumnosMatriculados = 32, sesionesSemanales = 9, mesesAno = 12;
        final short sesionesTotales = 240;
        
        System.out.println("Los alumnos matriculados son " + alumnosMatriculados);
        System.out.println("Las sesiones totales son " + sesionesTotales);
        System.out.println("Las sesiones semanales son " + sesionesSemanales);
        System.out.println("Los meses del año son " + mesesAno);

    }
}
