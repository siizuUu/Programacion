<?php
echo "Hola mundo.";
?>